a = "d"

if a :
    print "hsdf"
else :
    print "nein"