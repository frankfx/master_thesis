'''
Created on Jul 31, 2014

@author: fran_re
'''
class Shape(object):
    
    def __init__(self):
        self.rotX = 0.0
        self.rotY = 0.0
        self.rotZ = 0.0

        self.transX = 0.0
        self.transY = 0.0
        self.transZ = 0.0

    def setTransCoords(self,x,y,z):
        self.transX = x
        self.transY = y
        self.transZ = z    

    def setRotCoords(self,x,y,z):
        self.rotX = x
        self.rotY = y
        self.rotZ = z    
    
    def draw(self):
        raise NotImplementedError("Please Implement this method")