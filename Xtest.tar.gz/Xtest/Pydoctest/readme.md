<!-- create doc -->
pydoc -w foo
<!-- not foo.py  -->
