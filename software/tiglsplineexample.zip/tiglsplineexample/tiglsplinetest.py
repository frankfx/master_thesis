# -*- coding: utf-8 -*-
"""
This is an example project, how to query the bspline profile data from TiGL
and visualize it in python

Created on Fri Oct 17 14:10:34 2014

@author: sigg_ma
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import bspline

from tiglwrapper import Tigl, TiglException
from tixiwrapper import Tixi
import os

# change path to folder with TIGL.dll
os.environ['PATH'] = 'D:\\src\\tigl_refact\\build_64\\install\\bin;' + os.environ['PATH']

tixi = Tixi()
tixi.open('simpletest.cpacs.xml')

tigl = Tigl()

try:
    tigl.open(tixi,"")
except TiglException as err:    
    print 'Error opening tigl document: ', err.__str__()
    


profUIDs = ["NACA0012", "NACA0012", "fuselageCircleProfileuID"]
profIdx  = [1, 2, 1]

fig = plt.figure()
fig.add_subplot(111, projection="3d") 

for i in range(len(profUIDs)):
    uid = profUIDs[i]
    idx = profIdx[i]
    
    # get number of curves of the current profile
    ncurves = tigl.profileGetBSplineCount(uid)
    for icurve in range(ncurves):
        # get size of knot vector and number of control points
        (degree, ncp, nk) =  tigl.profileGetBSplineDataSizes(uid, icurve+1)
        # now get the data
        (cpx, cpy, cpz, knots) = tigl.profileGetBSplineData (uid, icurve+1, ncp, nk)

        # and visualize the spline using my b-spline class
        cp = np.vstack([cpx, cpy, cpz])
        kn = np.array(knots)
        
        spline = bspline.BSpline(cp, kn, degree)
        t = np.linspace(kn[0], kn[-1], 1000)
        res = spline.eval(t)
        
        plt.plot(res[0], res[1], res[2])
        # we could also visualize the control points of the spline
        # they don't really differ to the actual spline (in case of the wing)
        #plt.plot(cpx, cpy, cpz)


plt.show()
