# -*- coding: utf-8 -*-
"""
Created on Fri Aug 22 13:21:51 2014

@author: sigg_ma
"""

import numpy as np
from matplotlib import pyplot as plt
import unittest

class BSpline():
    def __init__(self, control_points, knots, degree):
        '''
        Args:
            knots (numpy array of float): knot vector for which t[i] <= t[i+1]
            control_points (2D numpy array): control points, with control_points.shape[1] = number of points
            degree (int): degree of the b-spline
            
        '''
        assert(control_points.shape[1] + degree + 1 == np.size(knots))        
        
        self.cp = control_points
        self.knots = knots
        self.degree = degree
        
    def eval(self, t):
        '''
        Evaluates the B-Spline at positions t
        
        Args:
            t (1d numpy array): parameters at which to evaluate the b-spline
        '''
        return b_spline_eval(self.knots, self.cp, self.degree, t)
        # uncomment, to test the slow (unvectorized) version
        #return deboor_array_py(self.knots, self.cp, self.degree, t)


def b_spline_basis_i(i, d, t, x):
    '''
    Computes the i-th b-spline basis function of degree d
    
    Args:
        i (int): The basis' functions index with 0 <= i < size(t) - d - 1
        d (int): Degree of the b-spline
        t (float array): Knot vector with t[i] <= t[i+1]
        x (1d numy array): Paramters, at which the spline is to be evaluated
        
    '''    
    
    assert(0 <= i < t.shape[0] - d - 1)
    res =  b_basis_rec(i,d,t,x)
    
    res[x < t[0]] = 0
    res[x > t[-1]] = 0
    return res

# compute basis function of b_spline
def b_basis_rec(i,d,t,x):
    '''
    Recursive implementation of basis function computation. Fully vectorized and thus faster as deboor.
    
    Can't be used for extrapolation currently.
    
    Args:
        i (int): The basis' functions index with 0 <= i < size(t) - d - 1
        d (int): Degree of the b-spline
        t (float array): Knot vector with t[i] <= t[i+1]
        x (1d numy array): Paramters, at which the spline is to be evaluated
        
    '''   
    
    res = 0. * x
    if d > 0:
        if (t[i+d] - t[i]) != 0.:
            res = res + (x - t[i])/(t[i+d] - t[i]) * b_basis_rec(i, d-1, t, x)
            
        if (t[i+1+d] - t[i+1]) != 0.:
            res = res + (t[i+1+d] - x)/(t[i+1+d] - t[i+1])*b_basis_rec(i+1, d-1, t,x)
    
    # special treatment for endpoint         
    elif t[i+1] < t[-1]:
        res[(t[i] <= x) & (x < t[i+1])] = 1
    else:
        res[t[i] <= x] = 1;
        
    return res


def b_spline_eval(t, cp, d, x):
    '''
    This is an implementation for b-spline evaluation. In contrast to the deboor
    algorithm, it computes the superposition of the b-spline basis functions.
    
    This implementation is faster then the cythonized deboor algorithm since
    it's completely vectorized
    
    Args:
        t (numpy array of float): knot vector for which t[i] <= t[i+1]
        cp (2D numpy array): control points, with cp.shape[1] = number of points
        d (int): degree of the b-spline
        x (float value of numpy array): parameter ar which the function is evaluated
        
    Returns:
        numpy array: The b-spline koordinates for each x parameter
    '''
    assert(cp.shape[1] + d + 1 == np.size(t))

    res = np.zeros([cp.shape[0], np.size(x)])
    for i in range(cp.shape[1]):
        res = res + cp[:,[i]]*b_spline_basis_i(i, d, t, x)
        
    return res


    
def deboor_impl_py(l,t,cp,n,x):
    '''
    Efficient implementation of the deboor algorithm
    
    Can also be used for extrapolation (i.e. x < t[0] or x > t[-1])
    
    Args:
        l (int): index such that t[l] <= x < t[l+1] (except from border cases)
        t  (numpy 1d array): knot vector with t[i] <= t[i+1]
        cp (numpy 2d array): control polygon, with cp.shape[1] = number of control pointspoints
        n (int): degree of the b-spline
        x (float): paramter at which the spline should be evaluated
    '''    
    
    # check correct length of knots and control point number
    n_cpoints = cp.shape[1]

    assert(n_cpoints + n + 1 == t.shape[0])
    # check that control point dimension is 1, 2, 3
    assert(cp.shape[0] < 4)
    
    assert(l >= n)
    assert(l <= n_cpoints)
    
    D = cp[:,l-n:l+1].copy()
    
    for k in xrange(1,n+1):
        for i in xrange(n, k-1, -1):
            alpha = (x - t[i+l-n])/(t[i+ n +1-k  +l-n] - t[i+l-n])
            D[:,i] = (1-alpha)*D[:,i-1] + alpha*D[:,i]
        
    return D[:,n]
 

def deboor_single_py(t, cp, d, x):
    idx = find_pos(d, t,x)
        
    return deboor_impl_py(idx, t,cp, d, x)
    
def deboor_array_py(t, cp, d, x):
    res = np.zeros([cp.shape[0], x.shape[0]])
    for i in xrange(np.size(x)):
        res[:,i] = deboor_single_py(t, cp, d, x[i])
    return res
     
def find_pos(d, t, x):
    '''
    Helper function for the deboor algorithm. 
    Returns i such that: t[i] <= x < t[i+1]
    
    Only exception are x values near the array borders which are 
    handled differently for the deboor algorithm.
    '''
    n = np.size(t)    
    
    if x < t[0]:
        return d
  
    for i in xrange(n-1):
        if t[i] <= x < t[i+1]: break

    if i < d:
        return d
        
    if i > n - d - 2:
        return n-d-2
       
    return i       
       
     
        
class BSplineTest(unittest.TestCase):
    def test_bezier_ident(self):
        '''
        We test, that for a purely clamped knot vector, the bspline is identical
        to the bezier spline
        '''
        import bezier
        
        # create degree 4 bezier/bspline
        cp = np.array([[0.0,0.0],
                       [1.0,1.0],
                       [1.5,0.8],
                       [2.0,1.0],
                       [3.0,0.0]]
                       ).transpose();       
        degree = 4
        knots = np.array([0,0,0,0,0,1,1,1,1,1])
        
        t = np.linspace(0,1,100000)
        bez_res = bezier.BezierSpline(cp).eval(t)
        bsp_res = BSpline(cp, knots, degree).eval(t)
        
        # compute error
        error = np.max(np.sqrt(np.sum((bez_res - bsp_res)**2, 0)))
        
        self.assertLess(error, 1e-12)
        

    def test_basis_ident(self):
        cp = np.array([[1.0],
                       [1.0],
                       [1.0],
                       [1.0],
                       [1.0],
                       [1.0],
                       [1.0]]
                       ).transpose();
                           
            
        n = 3
        
        k = np.array([-0.75,-0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0, 1.24, 1.5, 1.75])
        
        t = np.linspace(-0.75,1.75,1000)
        res = b_spline_eval(k,cp, n, t)
        
        # check that basis functions sum is 1 in x=[0,1] and smaller
        # than 1 on x<0 and x>1
        err1 =  np.max(np.abs(res[0,(0 <= t) & (t <= 1.0) ] - 1.))
        self.assertLess(err1, 1e-12)
        self.assertTrue(np.all( res[0, t < 0.0] < 1. ))
        self.assertTrue(np.all( res[0, t > 1.0] < 1. ))
        
        # create clamped vector, now all elements must be one
        t = np.linspace(0.,1.,1000)
        k = np.array([0., 0., 0., 0., 0.25, 0.5, 0.75, 1.0, 1.0, 1.0, 1.0])
        res = b_spline_eval(k,cp, n, t)
        err2 =  np.max(np.abs(res[0,:] - 1.))
        self.assertLess(err2, 1e-12)
 
   
    def test_find_pos(self):
        t = np.array([0.,1.,2.,3.,4.,5.])

        self.assertEqual(0, find_pos(0, t, 0))         
        self.assertEqual(1, find_pos(0, t, 1)) 
        self.assertEqual(3, find_pos(0, t, 3)) 

        self.assertEqual(2, find_pos(0, t, 2.5))
        self.assertEqual(3, find_pos(0, t, 3.9999))
        
        self.assertEqual(0, find_pos(0, t, -0.5))     
        

if __name__ == "__main__":    
    unittest.main()