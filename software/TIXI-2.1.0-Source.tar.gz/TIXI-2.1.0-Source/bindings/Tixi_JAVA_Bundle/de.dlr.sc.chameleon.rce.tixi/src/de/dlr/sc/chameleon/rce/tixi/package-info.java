/**
 * This package defines the TIXI jna interface.
 */
package de.dlr.sc.chameleon.rce.tixi;
