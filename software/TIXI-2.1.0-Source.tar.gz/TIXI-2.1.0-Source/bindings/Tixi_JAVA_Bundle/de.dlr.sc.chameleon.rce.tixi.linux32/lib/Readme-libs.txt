You might want to put all neccesary libs in here if you want to use or distribute the bundles with all dependencys.

libTIXI.so
libcurl.so
libxml2.so
libxslt.so

