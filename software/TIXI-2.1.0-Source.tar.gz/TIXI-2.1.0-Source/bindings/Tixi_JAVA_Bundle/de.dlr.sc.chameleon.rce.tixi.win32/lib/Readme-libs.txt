You might want to put all needed libs in here if you want to use or distribute the bundles with all dependencys.

TIXI.dll
curllib.dll
iconv.dll
libcurl.dll
libcurld.dll
libeay32.dll
libexslt.dll
libidn-11.dll
libsasl.dll
libssh2.dll
libssl32.dll
libxml2.dll
libxslt.dll
msvcr71d.dll
openldap.dll
ssleay32.dll
zlib1.dll